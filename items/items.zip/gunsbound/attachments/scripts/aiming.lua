local var1 = {}

function var1.init()

end

function var1.activate(dt)

end

function var1.update(dt)

end

function var1.uninit()

end

return var1